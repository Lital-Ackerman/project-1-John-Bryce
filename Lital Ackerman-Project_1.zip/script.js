
let notes=[];
let noteToArray;
let isFade;


function createNote(event){
    event.preventDefault();
    let messageInput= document.getElementById("messageInput");
    let dateInput= document.getElementById("dateInput");
    let timeInput= document.getElementById("timeInput");
    let dateWarning= document.getElementById("dateWarning");
    dateWarning.hidden= true;
    isFade =true; 

    let task= messageInput.value;
    let time= timeInput.value;
    let date= dateInput.value;


    if(isFuture(date, time)){
         date= date.split("-").reverse().join("/");
         let note= new Note(task, date, time);
         addNote(note)
    }else{
        dateWarning.hidden= false;
    }    
    
}


function isFuture(date, time) {
    const [hours, minutes]= time.split(":");
    date= new Date(date);
    date.setHours(hours, minutes, 0, 0);
    const today = new Date();
    return date > today
} 


function addNote(note){
    isFade= true;
    notes.push(note)
    displayNotes();
    saveStorage();
    }

function displayNotes(){
    let notesContainer= document.getElementById("notesContainer");
    let resetButton= document.getElementById("reset-btn");
    resetButton.click();
    notesContainer.innerHTML="";

    for (let index in notes) {
        if(index==(notes.length)-1 && isFade==true){
            notesContainer.innerHTML+=
            `<div id=${index} style="animation: fadeIn ease 4s">
                    <button onclick="deleteNote(${index})">X</button>
                    <p class="taskText">${notes[index].task}</p>
                    <footer>
                        <span class="dateText">${notes[index].date}</span>
                        <span class="timeText">${notes[index].time}</span>
                    </footer>
            </div>`;       
            }else{
            notesContainer.innerHTML+=
             `<div id=${index}>
                    <button onclick="deleteNote(${index})">X</button>
                    <p class="taskText">${notes[index].task}</p>
                    <footer>
                    <span class="dateText">${notes[index].date}</span>
                    <span class="timeText">${notes[index].time}</span>
                    </footer>
             </div>`;
        }
    }
}


function saveStorage(){
    localStorage.notes= JSON.stringify(notes);
}


function loadStorag(){
    isFade= false;
    let isStorage = localStorage.getItem("notes");
    notes= isStorage ? JSON.parse(localStorage.notes) : [];
    displayNotes();
}


function deleteNote(index){
    isFade= false;
    console.log(notes);
    notes.splice(index, 1)
    saveStorage()
    displayNotes();
}

function onReset(){
    dateWarning.hidden= true;
}



